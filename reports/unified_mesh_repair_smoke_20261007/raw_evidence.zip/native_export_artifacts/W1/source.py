# Fixed artificial cubes A/B, no historical case.
