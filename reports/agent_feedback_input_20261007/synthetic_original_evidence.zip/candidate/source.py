scene = None
